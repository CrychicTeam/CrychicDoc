# KubeJS教程-1.20.1
这是1.20.1的kubejs内容分享，包括一些教程和项目

直接访问该项目[gitbook网页](https://gumeng.gitbook.io/kubejs-jiao-cheng-1.20.1)

该项目的[开源地址Gitee](https://gitee.com/gumengmengs/kubejs-course)

该项目的[开源地址GitHub](https://github.com/Gu-meng/kubejs-course) GitHub不支持内容提交

孤梦的[bilibili主页](https://space.bilibili.com/16632546)

项目[问题反馈](https://gitee.com/gumengmengs/kubejs-course/issues/new/choose)

# 关于一些文件夹的帮助
## 文件夹分类
* KubeJS-Basics 存放kubejs基础内容
* kjs-jin-jie 存放kubejs的进阶内容
* kjs-mo-zu 存放关于kubejs周边的联动模组内容
* ti-wai-hua 存放除了kubejs代码以外可能需要知道的内容
* cai-zhi 存放关于assets资源内容
* KubeJS-Projects-Share 存放一些大家写的项目(对应的文件夹路径代表着对应的分享人)
* files 存放着文档里出现的可下载资源
* imgs 存放着文档里出现的图片,对应的路径代表着出现的位置
* code 存放着代码分享
  * Projects是项目分享的代码
  * This是教程中会涉及到的一些文件
* 提交
  * 在表格中有着`-` `~`和`?`三种类型, 其中`-`代表无, `~`代表待编辑, `?`代表不知道
  * 在提交和编写的时候注意一下不要修改