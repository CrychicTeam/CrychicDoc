---
description: 在这一章中将介绍KJS的基础使用
---

# kjs基础

