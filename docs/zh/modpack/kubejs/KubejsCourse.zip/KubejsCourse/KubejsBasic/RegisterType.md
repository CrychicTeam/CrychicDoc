# 使用ProbeJS查找物品、标签、方块注册名

7.0版本以上的ProbeJS文件路径：`游戏文件夹/.probe/startup/probe-types/global/registry_type.d.ts`