---
description: 该章节中的内容需要有一定的基础才能看得明白
---

# Ponder for KubeJS 进阶