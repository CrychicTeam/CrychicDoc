---
description: 该章节中提供了一些类的方法调用供参考
---

# Ponder for KubeJS 方法调用