---
description: 这一章中会简单的介绍kubejs中的材质(assets)使用
---

# assets的使用

